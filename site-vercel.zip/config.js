/* ==========================================================================
   CONFIGURAÇÃO CENTRAL DO SITE
   --------------------------------------------------------------------------
   É o único arquivo que precisa ser editado para colocar o site no ar:
   nome, WhatsApp e endereço. Todos os botões de agendamento e o mapa usam
   estes valores.

   Enquanto um campo estiver com o valor provisório (entre colchetes ou vazio),
   o site mostra o espaço reservado correspondente. Nada aqui foi inventado.
   ========================================================================== */
window.SITE_CONFIG = {

  /* ---- Profissional ---------------------------------------------------- */
  profissional: {
    // Como o nome aparece no site. Use "Dra." / "Dr." somente se a formação
    // e o registro profissional confirmarem esse tratamento. Ex.: "Maria Souza"
    nome: "Dra. Fabíola Castro",

    // 1 ou 2 letras usadas no monograma. Deixe vazio para derivar do nome.
    iniciais: "",

    // Linha de apoio no selo do topo. Ex.: "Esteticista"
    especialidade: "Esteticista",

    // Opcional. Ex.: "@perfil". Se ficar vazio, o selo mostra a especialidade.
    instagram: ""
  },

  /* ---- WhatsApp (conversão principal) ---------------------------------- */
  whatsapp: {
    // Código do país + DDD + número, somente dígitos. Ex.: "5511999999999"
    // PLACEHOLDER: troque pelo número real da profissional.
    telefone: "55DDDNUMERO",

    // Mensagem inicial da conversa.
    mensagem: "Olá! Gostaria de saber mais sobre os tratamentos e agendar uma consulta."
  },

  /* ---- Localização ------------------------------------------------------ */
  endereco: {
    // Endereço completo. Ex.: "Rua Exemplo, 123, Bairro, Cidade - UF, 00000-000"
    // Com o endereço preenchido, o mapa do Google Maps aparece automaticamente.
    texto: "",

    // Opcional: URL de incorporação copiada do Google Maps
    // (Compartilhar > Incorporar um mapa > src do iframe).
    mapaEmbedUrl: "",

    // Opcional: link do local no Google Maps (se vazio, é montado pelo endereço).
    mapaLink: ""
  },

  /* ---- Detalhes ---------------------------------------------------------- */
  selo: {
    // Texto que corre em volta do selo circular do topo (use MAIÚSCULAS).
    texto: "ESTÉTICA FACIAL E CORPORAL"
  },

  desenvolvedor: "[Nome ou marca do desenvolvedor]",

  /* ---- SEO (opcional) ---------------------------------------------------- */
  seo: {
    titulo: "",     // se preenchido, substitui o <title> da página
    descricao: ""   // se preenchido, substitui a meta description
  }
};

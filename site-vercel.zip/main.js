/* ==========================================================================
   main.js — comportamento da página
   1. Dados da configuração aplicados ao HTML (nome, monograma, selo…)
   2. Botões de WhatsApp (um único link configurável)
   3. Mapa do Google Maps (ou espaço reservado)
   4. Carrosséis (rolagem nativa + setas + indicadores)
   5. Padrão de monogramas da seção "Conheça"
   6. Animação de entrada sutil
   Sem dependências. Funciona abrindo o index.html direto do disco.
   ========================================================================== */
(function () {
  'use strict';

  var doc = document;
  var cfg = window.SITE_CONFIG || {};
  var prof = cfg.profissional || {};
  var wa = cfg.whatsapp || {};
  var addr = cfg.endereco || {};

  doc.documentElement.classList.add('js');

  function qsa(sel, root) { return Array.prototype.slice.call((root || doc).querySelectorAll(sel)); }
  function text(v) { return (v == null ? '' : String(v)).trim(); }

  /* ------------------------------------------------------------------------
     1. Dados da configuração
     ---------------------------------------------------------------------- */
  var nome = text(prof.nome) || '[Nome da Profissional]';
  var isPlaceholder = /^\s*\[/.test(nome);

  function deriveInitials(n) {
    if (/^\s*\[/.test(n)) { return 'N'; }
    var parts = n.replace(/^(dra?\.?)\s+/i, '').split(/\s+/).filter(function (p) {
      return p && !/^(da|de|do|das|dos|e)$/i.test(p);
    });
    if (!parts.length) { return 'N'; }
    var first = parts[0].charAt(0);
    var last = parts.length > 1 ? parts[parts.length - 1].charAt(0) : '';
    return (first + last).toUpperCase();
  }

  var iniciais = (text(prof.iniciais) || deriveInitials(nome)).toUpperCase().slice(0, 2);
  var handle = text(prof.instagram);
  if (handle && handle.charAt(0) !== '@') { handle = '@' + handle; }

  var values = {
    'nome': nome,
    'nome-vertical': nome.replace(/[\[\]]/g, '').replace(/^\s*dra?\.?\s+/i, '').toUpperCase(),
    'iniciais': iniciais,
    'iniciais-hero': iniciais.slice(-1),
    'chip-sub': handle || text(prof.especialidade) || 'Esteticista',
    'selo': (text(cfg.selo && cfg.selo.texto) || 'ESTÉTICA FACIAL E CORPORAL').toUpperCase() + ' • ',
    'desenvolvedor': text(cfg.desenvolvedor) || '[Nome ou marca do desenvolvedor]'
  };

  qsa('[data-bind]').forEach(function (el) {
    var key = el.getAttribute('data-bind');
    if (Object.prototype.hasOwnProperty.call(values, key)) { el.textContent = values[key]; }
  });

  /* Selo circular: o texto é configurável, então ele é repetido (se for curto) ou
     reduzido (se for longo) para preencher a circunferência sem sobrepor letras. */
  (function fitBadge() {
    var tp = doc.querySelector('.hero__badge textPath');
    if (!tp || typeof tp.getComputedTextLength !== 'function') { return; }
    var label = text(cfg.selo && cfg.selo.texto) || 'ESTÉTICA FACIAL E CORPORAL';
    label = label.toUpperCase();
    var holder = tp.parentNode;
    var TARGET = 410;           // comprimento da circunferência do texto (unidades do SVG)
    var FILL = 0.94;            // fração mínima ocupada pelas letras (o resto vira espaçamento)

    function fit() {
      try {
        tp.removeAttribute('textLength');
        holder.style.fontSize = '';
        tp.textContent = label + ' • ';
        var one = tp.getComputedTextLength();
        if (!one) { return; }
        var copies = Math.max(1, Math.round((TARGET * FILL) / one));
        if (copies > 1) {
          var chunk = label + ' • ';
          tp.textContent = new Array(copies + 1).join(chunk);
        }
        var natural = tp.getComputedTextLength();
        if (natural > TARGET * FILL) {
          var base = parseFloat(window.getComputedStyle(holder).fontSize) || 20;
          holder.style.fontSize = (base * (TARGET * FILL) / natural).toFixed(2) + 'px';
        }
        tp.setAttribute('textLength', String(TARGET));
      } catch (e) { /* mantém o texto original */ }
    }
    fit();
    if (doc.fonts && doc.fonts.ready) { doc.fonts.ready.then(fit); }
  })();

  if (cfg.seo && text(cfg.seo.titulo)) { doc.title = text(cfg.seo.titulo); }
  if (cfg.seo && text(cfg.seo.descricao)) {
    var meta = doc.querySelector('meta[name="description"]');
    if (meta) { meta.setAttribute('content', text(cfg.seo.descricao)); }
  }

  /* ------------------------------------------------------------------------
     2. WhatsApp
     ---------------------------------------------------------------------- */
  var phone = text(wa.telefone).replace(/\D/g, '');
  var waReady = phone.length >= 10 && phone.length <= 15;
  var message = text(wa.mensagem) || 'Olá! Gostaria de saber mais sobre os tratamentos e agendar uma consulta.';
  var waUrl = 'https://wa.me/' + (waReady ? phone : '') + '?text=' + encodeURIComponent(message);

  var toastEl = doc.querySelector('.toast');
  var toastTimer;
  function toast(html) {
    if (!toastEl) { return; }
    toastEl.innerHTML = html;
    toastEl.hidden = false;
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () { toastEl.hidden = true; }, 7000);
  }

  qsa('[data-whatsapp]').forEach(function (a) {
    a.setAttribute('href', waUrl);
    a.setAttribute('target', '_blank');
    a.setAttribute('rel', 'noopener noreferrer');
    if (!waReady) {
      a.setAttribute('data-wa-pending', 'true');
      a.addEventListener('click', function (ev) {
        ev.preventDefault();
        toast('O número do WhatsApp ainda não foi configurado. Defina <code>whatsapp.telefone</code> em <code>config.js</code>.');
      });
    }
  });
  if (!waReady && window.console) {
    console.warn('[site] WhatsApp não configurado: defina whatsapp.telefone em config.js (ex.: "5511999999999").');
  }

  /* ------------------------------------------------------------------------
     3. Mapa
     ---------------------------------------------------------------------- */
  (function initMap() {
    var box = doc.querySelector('[data-map]');
    if (!box) { return; }
    var address = text(addr.texto);
    var embed = text(addr.mapaEmbedUrl) || (address ? 'https://www.google.com/maps?q=' + encodeURIComponent(address) + '&output=embed' : '');
    var link = text(addr.mapaLink) || (address ? 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(address) : '');

    if (embed) {
      var frame = doc.createElement('iframe');
      frame.src = embed;
      frame.title = 'Mapa com a localização';
      frame.loading = 'lazy';
      frame.referrerPolicy = 'no-referrer-when-downgrade';
      frame.setAttribute('allowfullscreen', '');
      var ph = box.querySelector('[data-map-placeholder]');
      if (ph) { ph.hidden = true; }
      box.appendChild(frame);
    }

    var info = doc.querySelector('[data-map-info]');
    if (info && (address || link)) {
      var addrEl = info.querySelector('[data-address]');
      var linkEl = info.querySelector('[data-map-link]');
      if (addrEl) { addrEl.textContent = address; addrEl.hidden = !address; }
      if (linkEl) { if (link) { linkEl.href = link; } else { linkEl.hidden = true; } }
      info.hidden = false;
    }
  })();

  /* ------------------------------------------------------------------------
     4. Carrosséis
     ---------------------------------------------------------------------- */
  var reduceMotion = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };

  function initCarousel(root) {
    var track = root.querySelector('[data-track]');
    if (!track) { return; }
    var items = Array.prototype.slice.call(track.children);
    var prev = root.querySelector('[data-prev]');
    var next = root.querySelector('[data-next]');
    var dotsWrap = root.querySelector('[data-dots]');
    var dots = [];
    var ticking = false;

    function pitch() {
      return items.length > 1 ? (items[1].offsetLeft - items[0].offsetLeft) : track.clientWidth;
    }
    function maxScroll() { return track.scrollWidth - track.clientWidth; }
    function behavior() { return reduceMotion.matches ? 'auto' : 'smooth'; }
    function goTo(i) {
      track.scrollTo({ left: Math.max(0, Math.min(i * pitch(), maxScroll())), behavior: behavior() });
    }
    function step(dir) {
      var p = pitch();
      var visible = Math.max(1, Math.floor((track.clientWidth + 2) / p));
      track.scrollBy({ left: dir * visible * p, behavior: behavior() });
    }

    if (dotsWrap) {
      items.forEach(function (_, i) {
        var b = doc.createElement('button');
        b.type = 'button';
        b.className = 'dots__dot';
        b.setAttribute('aria-label', 'Ir para o item ' + (i + 1) + ' de ' + items.length);
        b.addEventListener('click', function () { goTo(i); });
        dotsWrap.appendChild(b);
        dots.push(b);
      });
    }
    if (prev) { prev.addEventListener('click', function () { step(-1); }); }
    if (next) { next.addEventListener('click', function () { step(1); }); }

    function update() {
      ticking = false;
      var left = track.scrollLeft;
      var max = maxScroll();
      var idx = Math.round(left / pitch());
      if (left >= max - 2) { idx = items.length - 1; }
      idx = Math.max(0, Math.min(items.length - 1, idx));
      dots.forEach(function (d, i) {
        var on = i === idx;
        d.classList.toggle('is-active', on);
        if (on) { d.setAttribute('aria-current', 'true'); } else { d.removeAttribute('aria-current'); }
      });
      if (prev) { prev.disabled = left <= 2; }
      if (next) { next.disabled = left >= max - 2; }
      root.classList.toggle('is-static', max <= 2);
    }
    function schedule() {
      if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
    }

    track.addEventListener('scroll', schedule, { passive: true });
    window.addEventListener('resize', schedule);
    if ('ResizeObserver' in window) { new ResizeObserver(schedule).observe(track); }
    update();
  }
  qsa('[data-carousel]').forEach(initCarousel);

  /* ------------------------------------------------------------------------
     5. Padrão de monogramas (seção "Conheça")
     ---------------------------------------------------------------------- */
  qsa('[data-mono-pattern]').forEach(function (svg) {
    var NS = 'http://www.w3.org/2000/svg';
    var XL = 'http://www.w3.org/1999/xlink';
    var cols = 7, rows = 11, dx = 330, dy = 215;
    var angles = [-9, -4, -12, -6];
    for (var r = 0; r < rows; r++) {
      for (var c = -1; c < cols; c++) {
        var x = c * dx + (r % 2 ? dx / 2 : 0) + 80;
        var y = 150 + r * dy;
        var use = doc.createElementNS(NS, 'use');
        use.setAttribute('href', '#mono-glyph');
        use.setAttributeNS(XL, 'xlink:href', '#mono-glyph');
        use.setAttribute('transform', 'translate(' + x + ' ' + y + ') rotate(' + angles[(r + c + 8) % angles.length] + ')');
        svg.appendChild(use);
      }
    }
  });

  /* ------------------------------------------------------------------------
     6. Animação de entrada (apenas um deslocamento sutil; nada fica invisível)
     ---------------------------------------------------------------------- */
  var revealEls = qsa('[data-reveal]');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.05 });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('is-in'); });
  }

  /* Pequeno atalho para quem configura o site: mostra o que ainda é provisório. */
  if (isPlaceholder && window.console) {
    console.info('[site] Conteúdo provisório ativo: nome, WhatsApp, endereço, fotos e tratamentos de demonstração.');
  }
})();

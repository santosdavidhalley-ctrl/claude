# Landing page — esteticista

Página única (HTML + CSS + JavaScript puro, sem etapa de build) para uma profissional de estética:
hero, apresentação, tratamentos, "Conheça", diferenciais, localização e rodapé.
Reconstrói a composição da referência visual enviada e converte pelo **WhatsApp**.

> **Status:** o site funciona por completo, mas ainda usa **conteúdo provisório**.
> Nada foi inventado: nome, telefone, endereço, fotos e tratamentos estão marcados como espaço reservado.

## Como abrir

Dê dois cliques em `index.html` (funciona direto do disco) ou envie a pasta inteira para qualquer
hospedagem estática (Netlify, Vercel, GitHub Pages, Cloudflare Pages, Hostinger, etc.).
As fontes vêm do Google Fonts, então a primeira abertura precisa de internet.

## Publicar no Vercel (pelo GitHub)

Todos os arquivos ficam **na mesma pasta, sem subpastas**, para que o upload pelo site do GitHub não quebre os caminhos.

1. No repositório do GitHub, apague os arquivos antigos (ou crie um repositório novo).
2. **Add file → Upload files** e arraste **todos os arquivos desta pasta** (não a pasta em si, nem o .zip).
   Confira que `index.html`, `style.css`, `config.js` e `main.js` aparecem na raiz do repositório.
3. No Vercel: *Add New → Project*, escolha o repositório, **Framework Preset: Other**, sem Build Command,
   **Root Directory** vazio (raiz). Clique em *Deploy*. Cada novo commit publica automaticamente.

```
index.html      página
style.css       todo o visual (cores, fontes, layout)
config.js       ★ nome, WhatsApp, endereço — o único arquivo que precisa editar
main.js         comportamento (não precisa mexer)
*.svg / *.png   imagens provisórias, favicon e textura
vercel.json     configuração do Vercel (URLs limpas e cabeçalhos de segurança)
```

## 1) O que preencher — `config.js`

| Campo | O que fazer |
|---|---|
| `profissional.nome` | Nome como deve aparecer. **Use "Dra./Dr." só se a formação confirmar.** Alimenta a assinatura, o nome vertical das bordas do topo, o selo, o título "Conheça…". |
| `profissional.instagram` | Opcional (ex.: `"@perfil"`); aparece no selo do topo. |
| `whatsapp.telefone` | País + DDD + número, só dígitos (ex.: `"5511999999999"`). **Todos os botões de agendamento usam este único valor.** |
| `whatsapp.mensagem` | Mensagem inicial da conversa (já vem preenchida). |
| `endereco.texto` | Endereço completo. Ao preencher, o mapa do Google aparece sozinho, com o link "Abrir no Google Maps". |
| `endereco.mapaEmbedUrl` / `mapaLink` | Opcionais, se quiser um mapa/link específico. |
| `selo.texto` | Texto que gira no selo circular do topo. |
| `desenvolvedor` | Crédito do rodapé ("Desenvolvido por …"). |
| `seo.titulo` / `seo.descricao` | Opcionais; substituem `<title>` e meta description. |

Enquanto o telefone for o provisório (`55DDDNUMERO`), clicar em qualquer botão de agendamento mostra
um aviso na tela em vez de abrir um WhatsApp sem número.

## 2) Fotos — a pasta principal

Substitua o arquivo mantendo o nome (ou troque o `src` no `index.html`) e **atualize o texto `alt`**.
Formatos aceitos: `.jpg`, `.webp`, `.png`, `.svg`.

| Arquivo | Onde aparece | Recomendado |
|---|---|---|
| `fabiola-castro-retrato.jpg` | Foto grande do topo (lado direito) | **PNG/WebP recortado (fundo transparente)**, ~1600 × 2000 px (4:5), pessoa ocupando quase toda a altura |
| `fabiola-castro-consultorio.jpg` | Seção "Conheça" | JPG/WebP ~1200 × 1600 px (3:4), enquadramento do busto para cima |
| `tratamento-01…06.svg` | Faixa de fotos de "Nossos Tratamentos" | JPG/WebP quadradas ~800 × 800 px |
| `favicon.svg` | Ícone da aba | Neutro; troque pelo logotipo quando existir |
| `grain.png`, `mapa-placeholder.svg` | Textura e fundo do espaço do mapa | Não precisam ser trocadas |

As imagens provisórias são ilustrações genéricas na paleta do site. **Não representam a profissional**
e a foto da referência não foi reutilizada. Se mudar a extensão do arquivo do hero, ajuste também os
atributos `width`/`height` da tag `<img class="hero__photo">`.

## 3) Textos e tratamentos

- **Tratamentos disponíveis:** os 6 cartões são **conteúdo de demonstração** (marcados com `data-demo` e com um
  comentário no HTML). Troque pelos tratamentos reais confirmados; não afirme procedimentos que a profissional não realiza.
  Para adicionar um, copie um bloco `<li class="card">`; para remover, apague-o. Os indicadores e as setas se ajustam sozinhos.
- **Fotos da faixa:** cada `<li class="strip__item">` é uma foto; copie/apague conforme necessário.
- **"Conheça":** há um parágrafo entre colchetes ("Espaço reservado: formação, experiência…"). Substitua por texto
  real, confirmado pela profissional (formação, registro, experiência). Evite prometer resultados.
- **Cores e fontes:** `style.css (bloco `:root` no início)`. Fontes: Poppins (textos) e Mrs Saint Delafield (assinatura e monograma).
  Para hospedar as fontes você mesmo (LGPD/desempenho), baixe-as, declare com `@font-face` e remova os `<link>` do Google Fonts.

## 4) Antes de publicar (checklist)

- [ ] Nome, telefone, endereço e crédito do desenvolvedor em `config.js`
- [ ] Foto do topo (recorte) e foto do "Conheça"
- [ ] Fotos da faixa de tratamentos e cartões reais
- [ ] Texto do "Conheça" confirmado pela profissional
- [ ] `<title>` / descrição (ou `seo.*` no `config.js`)
- [ ] Opcional: `og:image`, `canonical` e o bloco JSON-LD (já comentados no `<head>`; só preencher com dados reais)
- [ ] Opcional: logotipo → favicon
- [ ] Testar o botão de WhatsApp em um celular depois de configurar o número

## 5) O que foi verificado (e o que não foi)

**Verificado, com navegador Chromium automatizado:**
- Sem rolagem horizontal em 320, 360, 390, 700, 768, 820, 900, 1024, 1100, 1280, 1440 e 1920 px.
- Comparação visual com a referência em 1920 px: altura de cada seção dentro de poucos pixels (página inteira: 4130 px × 4128 px da referência).
- Layouts distintos para celular (coluna única), tablet (hero em duas colunas, 640–899 px) e desktop (composição da referência, que escala proporcionalmente).
- Botão de WhatsApp (link `wa.me/<número>?text=<mensagem>` com um número de teste), aviso quando o número não está configurado, mapa a partir do endereço, carrosséis (setas, indicadores, fim de curso), foco por teclado, `prefers-reduced-motion`, alvos de toque no celular.
- Contraste de texto WCAG AA medido em todas as larguras acima.

**Não verificado:**
- As **fontes do Google** não carregaram no ambiente de teste. A assinatura/monograma foram testados com fontes manuscritas substitutas;
  com a fonte real, o tamanho pode pedir ajuste fino (`.hero__signature`, `.hero__monogram-letter`, `.about__mono`).
- Apenas Chromium foi usado. Safari/iOS, Firefox e aparelhos reais não foram testados.
- O mapa incorporado do Google e o WhatsApp real dependem de rede e do número definitivo.

## 6) Desvios intencionais em relação à referência

- Textos claros sobre laranja/pêssego foram levemente escurecidos para atingir contraste legível (título do topo, degradês, rodapé).
- Botões de degradê usam tom mais escuro; o botão claro da seção de tratamentos usa texto marrom.
- Setas dos carrosséis ficam sobre a borda dos cartões (e não sobre o texto); no celular a rolagem é por toque.
- Imagens, nome, textos de apoio e cartões são provisórios; o mapa é um espaço reservado até haver endereço.

## Sobre o conteúdo

Sem preços, depoimentos inventados, FAQ, promessas de resultado ou credenciais não confirmadas.
